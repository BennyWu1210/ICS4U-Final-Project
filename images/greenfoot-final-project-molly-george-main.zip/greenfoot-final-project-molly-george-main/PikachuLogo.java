import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class PikachuLogo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PikachuLogo extends Pikachu
{
    
    public PikachuLogo()
    {
        setImage(new GreenfootImage("PikachuaLogo.png"));
    }
    
    public void act()
    {
        // Add your action code here.
    }
}

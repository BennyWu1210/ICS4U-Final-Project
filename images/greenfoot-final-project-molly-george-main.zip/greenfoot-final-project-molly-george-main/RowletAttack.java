import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class RowletAttack here.
 * 
 * @author George Lu && Molly Wu 
 * @version June 2022
 */
public class RowletAttack extends Damage
{
    
    
    public RowletAttack(GreenfootImage image)
    {
        setImage(image);
    }
    
    
    public void act()
    {
        
    }
}

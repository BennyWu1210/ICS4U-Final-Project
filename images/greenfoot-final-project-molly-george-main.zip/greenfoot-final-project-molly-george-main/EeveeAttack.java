import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EeveeAttack here.
 * 
 * @author George Lu && Molly Wu 
 * @version June 2022
 */
public class EeveeAttack extends Damage
{
    private SimpleTimer timer = new SimpleTimer();
    
    public EeveeAttack(GreenfootImage image)
    {
        setImage(image);
    }
    
    
    public void act()
    {
        
    }
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FennekinAttack here.
 * 
 * @author George Lu && Molly Wu 
 * @version June 2022
 */
public class FennekinAttack extends Damage
{
    public FennekinAttack()
    {
        setImage(new GreenfootImage("FennekinAtt.png"));
    }
    
    
    public void act()
    {
        
    }
}

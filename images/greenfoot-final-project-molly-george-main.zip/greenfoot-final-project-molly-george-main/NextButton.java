import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class NextButton here.
 * 
 * @author George Lu && Molly Wu 
 * @version June 2022
 */
public class NextButton extends NewLabelClass
{
    
    public NextButton()
    {
        setImage(new GreenfootImage("Next.png"));
    }
    
    public void act()
    {
        
    }
}
